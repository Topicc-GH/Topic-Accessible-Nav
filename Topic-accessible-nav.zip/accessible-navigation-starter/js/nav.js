//Add your JS here for your menu
const navMenuPaints = document.getElementById('navMenuPaints');
const MenuPaints = document.getElementById('MenuPaints');
const Acrylic = document.getElementById('Acrylic');
const bar = document.querySelector(".nav-toggle");
const megaPanel = document.querySelector(".mega-panel-inner");
const button = document.querySelector("button");
const paintsHeading = document.getElementById('.paint')
const drawingHeading = document.getElementById('.draw')
const surfaceHeading = document.getElementById('.surface')
const toolsHeading = document.getElementById('.tools')
const studioHeading = document.getElementById('.studio')
const saleHeading = document.getElementById('.heading')

bar.addEventListener("click", () => {
    bar.classList.toggle("active");
    megaPanel.classList.toggle("active");
})

navMenuPaints.addEventListener('click', () => {
    const isActive = MenuPaints.classList.toggle('active');
});

navMenuPaints.addEventListener('click', () => {
    const isActive = Acrylic.classList.toggle('active');
});

const navMenuDrawing = document.getElementById('navMenuDrawing');

const MenuDraw = document.getElementById('MenuDraw');

const PensMarker = document.getElementById('PensMarker');

navMenuDrawing.addEventListener('click', () => {
    const isActive = MenuDraw.classList.toggle('active');
});

navMenuDrawing.addEventListener('click', () => {
    const isActive = PensMarker.classList.toggle('active');
});

const navMenuTools = document.getElementById('navMenuTools');

const MenuBrush = document.getElementById('MenuBrush');

const Brushes = document.getElementById('Brushes');

navMenuTools.addEventListener('click', () => {
    const isActive = MenuBrush.classList.toggle('active');
});

navMenuTools.addEventListener('click', () => {
    const isActive = Brushes.classList.toggle('active');
});

console.log(paintsHeading.ariaLabel);
paintsHeading.ariaLabel = 'Close Menu'; 

console.log(drawingHeading.ariaLabel);
drawingHeading.ariaLabel = 'Close Menu'; 

console.log(surfaceHeading.ariaLabel);
surfaceHeading.ariaLabel = 'Close Menu'; 

console.log(toolsHeading.ariaLabel);
toolsHeading.ariaLabel = 'Close Menu'; 

console.log(studioHeading.ariaLabel);
studioHeading.ariaLabel = 'Close Menu'; 

console.log(saleHeading.ariaLabel);
saleHeading.ariaLabel = 'Close Menu'; 